"""
generate_data.py
-----------------
Generates 90 days of synthetic daily sales + inventory + financial data
for 12 retail grocery items and writes it into retail.db (sales_data table).

Features:
- Realistic daily Gaussian sales distribution with weekly restocking cycle.
- Unit prices for financial impact calculation (Revenue & Stock Value).
- Intentionally injected anomalies:
  * Sales Spikes (sudden demand surges)
  * Sales Drops (unexpected 0-sales days)
  * Inventory Shrinkage (theft/damage where stock drops without sales)
  * Stockout events (inventory hitting 0)
"""

import sqlite3
import random
from datetime import date, timedelta

DB_PATH = "retail.db"
NUM_DAYS = 90
START_DATE = date.today() - timedelta(days=NUM_DAYS)

# 12 grocery items with baseline parameters and unit prices (in INR - Indian Rupees ₹)
ITEMS = [
    {"name": "Milk (1L)",       "sales_mean": 80,  "sales_std": 8,  "inv_start": 500, "unit_price": 60.00},
    {"name": "Bread (Loaf)",    "sales_mean": 60,  "sales_std": 6,  "inv_start": 300, "unit_price": 40.00},
    {"name": "Eggs (Dozen)",    "sales_mean": 50,  "sales_std": 5,  "inv_start": 400, "unit_price": 84.00},
    {"name": "Rice (5kg)",      "sales_mean": 30,  "sales_std": 4,  "inv_start": 250, "unit_price": 320.00},
    {"name": "Chicken (1kg)",   "sales_mean": 40,  "sales_std": 5,  "inv_start": 200, "unit_price": 240.00},
    {"name": "Toilet Paper",    "sales_mean": 45,  "sales_std": 5,  "inv_start": 350, "unit_price": 120.00},
    {"name": "Cooking Oil",     "sales_mean": 35,  "sales_std": 4,  "inv_start": 220, "unit_price": 150.00},
    {"name": "Sugar (1kg)",     "sales_mean": 38,  "sales_std": 4,  "inv_start": 260, "unit_price": 45.00},
    {"name": "Tea (250g)",      "sales_mean": 42,  "sales_std": 5,  "inv_start": 280, "unit_price": 110.00},
    {"name": "Detergent",       "sales_mean": 28,  "sales_std": 3,  "inv_start": 180, "unit_price": 95.00},
    {"name": "Biscuits",        "sales_mean": 55,  "sales_std": 6,  "inv_start": 320, "unit_price": 30.00},
    {"name": "Onions (1kg)",    "sales_mean": 65,  "sales_std": 7,  "inv_start": 310, "unit_price": 35.00},
]

# Injected ground-truth anomalies: (item_name, day_offset, anomaly_type, parameter)
INJECTED_ANOMALIES = [
    ("Milk (1L)",     25, "spike",      4.6),  # Huge surge (party/event)
    ("Bread (Loaf)",  38, "drop",       0.0),  # Sudden drop (holiday/delivery issue)
    ("Eggs (Dozen)",  45, "shrinkage",  120),  # 120 units damaged/stolen
    ("Rice (5kg)",    52, "spike",      4.5),  # Bulk purchase spike
    ("Chicken (1kg)", 60, "stockout",   0),    # Ran out of stock
    ("Toilet Paper",  70, "spike",      4.4),  # Panic buying spike
    ("Cooking Oil",   78, "shrinkage",  90),   # 90 units leakage/loss
    ("Biscuits",      84, "drop",       0.0),  # Drop to 0
]


def build_dataset():
    rows = []
    inventory = {item["name"]: item["inv_start"] for item in ITEMS}
    injected_lookup = {(a[0], a[1]): a for a in INJECTED_ANOMALIES}

    for day_offset in range(NUM_DAYS):
        current_date = START_DATE + timedelta(days=day_offset)
        for item in ITEMS:
            name = item["name"]
            unit_price = item["unit_price"]
            base_sales = max(0, round(random.gauss(item["sales_mean"], item["sales_std"])))

            key = (name, day_offset)
            is_anomaly = 0
            if key in injected_lookup:
                _, _, atype, factor = injected_lookup[key]
                if atype == "spike":
                    base_sales = round(item["sales_mean"] * factor)
                    is_anomaly = 1
                elif atype == "drop":
                    base_sales = 0
                    is_anomaly = 1
                elif atype == "shrinkage":
                    # Unexplained inventory drop without extra sales
                    inventory[name] = max(0, inventory[name] - int(factor))
                    is_anomaly = 1
                elif atype == "stockout":
                    inventory[name] = 0
                    base_sales = 0
                    is_anomaly = 1

            # Standard inventory decrement
            inventory[name] -= base_sales

            # Weekly replenishment
            if day_offset % 7 == 0:
                inventory[name] += item["sales_mean"] * 8

            inventory[name] = max(0, inventory[name])
            revenue = round(base_sales * unit_price, 2)
            stock_value = round(inventory[name] * unit_price, 2)

            rows.append((
                current_date.isoformat(),
                name,
                base_sales,
                inventory[name],
                unit_price,
                revenue,
                stock_value,
                is_anomaly,
            ))
    return rows


def main():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("DROP TABLE IF EXISTS sales_data")
    cur.execute("""
        CREATE TABLE sales_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            record_date TEXT NOT NULL,
            item TEXT NOT NULL,
            sales INTEGER NOT NULL,
            inventory INTEGER NOT NULL,
            unit_price REAL NOT NULL,
            revenue REAL NOT NULL,
            stock_value REAL NOT NULL,
            is_injected_anomaly INTEGER NOT NULL DEFAULT 0
        )
    """)
    rows = build_dataset()
    cur.executemany("""
        INSERT INTO sales_data (
            record_date, item, sales, inventory, unit_price, revenue, stock_value, is_injected_anomaly
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    """, rows)
    conn.commit()
    conn.close()
    print(f"[SUCCESS] Generated {len(rows)} rows across {len(ITEMS)} items and {NUM_DAYS} days.")
    print(f"          Injected {len(INJECTED_ANOMALIES)} known ground-truth anomalies.")
    print(f"          Database saved: {DB_PATH}")


if __name__ == "__main__":
    main()
